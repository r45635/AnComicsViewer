"""
Interface utilisateur AnComicsViewer
===================================

Composants PySide6 pour l'interface graphique.
"""

__all__ = []
