# detectors/postproc.py
from typing import List, Tuple
import numpy as np, cv2
from PySide6.QtCore import QRectF, QSizeF

def lab_L(rgb: np.ndarray) -> np.ndarray:
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    L = lab[:, :, 0]
    return cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(L)

def find_runs(bool_arr, min_len: int):
    runs, start = [], None
    for i, v in enumerate(list(bool_arr) + [False]):
        if v and start is None:
            start = i
        elif (not v) and start is not None:
            if i - start >= min_len:
                runs.append((start, i))
            start = None
    return runs

def _closest_center(runs, target: int):
    if not runs:
        return target
    return min(((abs(((a+b)//2) - target), (a+b)//2) for a, b in runs))[1]

def snap_rect_to_gutters(
    L_img: np.ndarray,
    rect: QRectF,
    page_size: QSizeF,
    px_per_pt: float,
    min_gutter_px: int = 8,
    cov: float = 0.90,
    max_expand_frac: float = 0.04,
    smooth_k: int = 17,
) -> QRectF:
    H, W = L_img.shape[:2]
    x0 = max(0, int(round(rect.left()   * px_per_pt)))
    y0 = max(0, int(round(rect.top()    * px_per_pt)))
    ww = max(1, int(round(rect.width()  * px_per_pt)))
    hh = max(1, int(round(rect.height() * px_per_pt)))

    pad = int(max_expand_frac * min(W, H))
    xa = max(0, x0 - pad); ya = max(0, y0 - pad)
    xb = min(W, x0 + ww + pad); yb = min(H, y0 + hh + pad)
    roi = L_img[ya:yb, xa:xb].astype(np.float32) / 255.0
    if roi.size == 0:
        return rect

    col = roi.mean(axis=0); row = roi.mean(axis=1)
    k = max(9, smooth_k)
    if col.size >= k: col = np.convolve(col, np.ones(k) / k, mode="same")
    if row.size >= k: row = np.convolve(row, np.ones(k) / k, mode="same")

    ct = (col.max() - col.min()) * 0.15 + col.mean()
    rt = (row.max() - row.min()) * 0.15 + row.mean()
    vbin = col >= ct; hbin = row >= rt

    v_runs = find_runs(vbin, min_gutter_px)
    h_runs = find_runs(hbin, min_gutter_px)

    Lx = x0 - xa; Rx = x0 + ww - xa
    Ty = y0 - ya; By = y0 + hh - ya

    newL = _closest_center(v_runs, Lx)
    newR = _closest_center(v_runs, Rx)
    newT = _closest_center(h_runs, Ty)
    newB = _closest_center(h_runs, By)

    nx = (xa + min(newL, newR)) / px_per_pt
    ny = (ya + min(newT, newB)) / px_per_pt
    nw = max(1.0 / px_per_pt, abs((xa + newR) - (xa + newL)) / px_per_pt)
    nh = max(1.0 / px_per_pt, abs((ya + newB) - (ya + newT)) / px_per_pt)
    return QRectF(nx, ny, nw, nh)

def snap_rect_to_gutters_rgb(
    rgb_img: np.ndarray,
    rect: QRectF,
    page_size: QSizeF,
    px_per_pt: float,
    min_gutter_px: int = 8,
    cov: float = 0.90,
    max_expand_frac: float = 0.04,
    smooth_k: int = 17,
) -> QRectF:
    """Version qui accepte une image RGB et fait la conversion LAB en interne."""
    L_img = lab_L(rgb_img)
    return snap_rect_to_gutters(L_img, rect, page_size, px_per_pt, min_gutter_px, cov, max_expand_frac, smooth_k)
