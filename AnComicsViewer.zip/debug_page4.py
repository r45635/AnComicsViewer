#!/usr/bin/env python3
"""Debug detection on page 4 with different parameters."""
import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QImage
from PySide6.QtCore import QSizeF
from PySide6.QtPdf import QPdfDocument

from ancomicsviewer import PanelDetector
from ancomicsviewer.config import DetectorConfig

def analyze_page(pdf_path: str, page_num: int = 4, dpi: float = 150.0):
    app = QApplication(sys.argv)

    # Load PDF
    doc = QPdfDocument()
    doc.load(pdf_path)

    page_size = doc.pagePointSize(page_num)
    print(f"Page {page_num}: {page_size.width():.1f} x {page_size.height():.1f} points")

    # Render at higher DPI for better gutter detection
    scale = dpi / 72.0
    img_size = page_size * scale
    qimage = doc.render(page_num, img_size.toSize())
    print(f"Rendered: {qimage.width()} x {qimage.height()} pixels @ {dpi} DPI\n")

    # Test different configurations
    configs = [
        ("Default", DetectorConfig(debug=True)),
        ("Sensitive gutters", DetectorConfig(
            debug=True,
            min_gutter_px=2,        # More sensitive to thin gutters
            min_gutter_frac=0.005,  # Smaller minimum gutter fraction
            gutter_cov_min=0.75,    # Lower brightness requirement
            light_col_rel=0.08,     # More sensitive light column detection
            light_row_rel=0.08,
        )),
        ("Higher DPI + sensitive", DetectorConfig(
            debug=True,
            min_gutter_px=3,
            gutter_cov_min=0.78,
            morph_kernel=3,         # Smaller kernel preserves thin gutters
            morph_iter=1,
        )),
    ]

    for name, config in configs:
        print(f"\n{'='*50}")
        print(f"Config: {name}")
        print('='*50)

        detector = PanelDetector(config)
        panels = detector.detect_panels(qimage, page_size)

        print(f"\nResults: {len(panels)} panels")
        for i, p in enumerate(panels):
            row = int((p.y() - 60) / 190) + 1  # Approximate row
            print(f"  #{i+1} (row {row}): x={p.x():.0f} y={p.y():.0f} w={p.width():.0f} h={p.height():.0f}")

if __name__ == "__main__":
    pdf_path = "samples_PDF/Tintin - 161 - Le Lotus Bleu - .pdf"

    # Test at different DPIs
    print("Testing at 150 DPI:")
    analyze_page(pdf_path, page_num=4, dpi=150.0)

    print("\n\n" + "="*60)
    print("Testing at 200 DPI (better gutter detection):")
    print("="*60)
    analyze_page(pdf_path, page_num=4, dpi=200.0)
