#!/usr/bin/env python3
"""Save page 4 with detection overlay for visual debugging."""
import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QImage, QPainter, QColor, QPen, QFont
from PySide6.QtCore import QRectF
from PySide6.QtPdf import QPdfDocument

from ancomicsviewer import PanelDetector
from ancomicsviewer.config import DetectorConfig

def main():
    app = QApplication(sys.argv)

    # Load PDF
    doc = QPdfDocument()
    doc.load("samples_PDF/Tintin - 161 - Le Lotus Bleu - .pdf")

    page_num = 4
    page_size = doc.pagePointSize(page_num)

    # Render at 150 DPI
    dpi = 150.0
    scale = dpi / 72.0
    img_size = page_size * scale
    qimage = doc.render(page_num, img_size.toSize())

    # Convert to format that supports painting
    qimage = qimage.convertToFormat(QImage.Format.Format_RGB32)

    # Detect panels
    config = DetectorConfig(debug=False)
    detector = PanelDetector(config)
    panels = detector.detect_panels(qimage, page_size)

    print(f"Page {page_num}: {len(panels)} panels detected")

    # Draw overlays
    painter = QPainter(qimage)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    # Draw each panel
    pen = QPen(QColor(0, 200, 0, 220), 3)
    fill = QColor(0, 200, 0, 40)

    font = QFont()
    font.setPixelSize(24)
    font.setBold(True)
    painter.setFont(font)

    for i, p in enumerate(panels):
        # Convert from page points to pixels
        rect = QRectF(
            p.x() * scale,
            p.y() * scale,
            p.width() * scale,
            p.height() * scale
        )

        painter.setPen(pen)
        painter.setBrush(fill)
        painter.drawRect(rect)

        # Draw panel number
        painter.setPen(QColor(255, 0, 0))
        painter.drawText(rect.adjusted(5, 5, 0, 0), f"#{i+1}")

        print(f"  #{i+1}: ({p.x():.0f},{p.y():.0f}) {p.width():.0f}x{p.height():.0f}")

    painter.end()

    # Save
    output_path = "/tmp/page4_with_overlay.png"
    qimage.save(output_path)
    print(f"\nSaved: {output_path}")

if __name__ == "__main__":
    main()
